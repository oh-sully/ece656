#!/usr/bin/env bash

zip -r 656-3-employees-starter.zip *

