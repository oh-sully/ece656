#!/usr/bin/env bash

zip -r 656-1-yelp.zip *
