SELECT AVG(review_count) AS avg_reviews
FROM user;