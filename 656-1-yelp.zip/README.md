1. Please fill in each file with query only for corresponding question. 

2. You can use package.sh to generate a zip package for uploading. 