CREATE VIEW revlen AS
SELECT user_id, (length(R.text)) AS rLen
FROM review AS R;
#WHERE user_id IN (SELECT id AS user_id FROM user WHERE review_count > 10);

SELECT AVG(rLen) AS avg_length
FROM revlen;