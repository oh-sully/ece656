SELECT name, review_count AS max_review
FROM business
ORDER BY max_review desc
LIMIT 1;