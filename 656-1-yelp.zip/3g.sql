SELECT (
	(SELECT COUNT(id) FROM user WHERE review_count > 10) 
	/ 
	(SELECT COUNT(id) FROM user)) AS fraction;