CREATE VIEW user_avg AS
SELECT id AS user_id, average_stars AS avg_s
FROM user;

CREATE VIEW rev_avg AS
SELECT user_id, AVG(stars) AS avg_stars
FROM review
GROUP BY user_id;

SELECT COUNT(U.user_id) AS count
FROM user_avg AS U NATURAL JOIN rev_avg as R
WHERE ABS(U.avg_s - R.avg_stars) > 0.5;