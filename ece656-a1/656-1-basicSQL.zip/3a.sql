UPDATE Employee as E
SET E.salary = E.salary * 1.10
WHERE empID in (SELECT empID FROM Assigned as A WHERE A.projID = 345);