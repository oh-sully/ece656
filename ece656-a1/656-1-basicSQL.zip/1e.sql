SELECT COUNT(deptID) as engineer_number, deptID
FROM Employee
WHERE job = 'engineer'
GROUP BY (deptID)
ORDER BY engineer_number desc
LIMIT 1;