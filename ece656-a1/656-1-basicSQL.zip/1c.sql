SELECT empName, salary
FROM Employee
WHERE job = 'engineer';