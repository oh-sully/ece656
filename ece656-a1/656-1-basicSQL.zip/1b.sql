SELECT count(job) as employees, job
FROM Employee
GROUP BY job
ORDER BY job;