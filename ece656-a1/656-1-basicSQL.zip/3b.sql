UPDATE Employee as E NATURAL JOIN Department as D
SET E.salary = 
CASE
	WHEN D.location = 'Waterloo' THEN E.salary * 1.08
	WHEN E.job = 'janitor' THEN E.salary * 1.05
	ELSE E.salary
END;