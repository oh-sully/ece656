SELECT E.empID, empName
FROM Employee as E
LEFT OUTER JOIN Assigned as A
ON E.empID = A.empID
WHERE A.empID IS NULL;