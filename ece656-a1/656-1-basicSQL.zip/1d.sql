SELECT AVG(salary) as avg_salary, job
FROM Employee
GROUP BY job;