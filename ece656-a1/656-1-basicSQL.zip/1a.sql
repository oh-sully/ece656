#1a
SELECT deptName
FROM Department
WHERE location = 'Waterloo';