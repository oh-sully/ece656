SELECT I.projID, I.totSalary
FROM(
	SELECT projID, SUM(salary) AS totSalary
	FROM Employee AS E NATURAL JOIN Assigned AS A
	GROUP BY projID
	UNION
	SELECT projID, SUM(salary)
	FROM Employee AS E LEFT OUTER JOIN Assigned AS A ON E.empID = A.empID
	WHERE A.empID IS NULL
	GROUP BY projID
	) AS I 
	LEFT OUTER JOIN 
	Project AS P
	ON I.projID = P.projID;