SELECT P.projID, SUM(E.salary) AS totSalary
FROM (Employee AS E NATURAL JOIN Assigned AS A) NATURAL JOIN Project AS P
GROUP BY P.projID;