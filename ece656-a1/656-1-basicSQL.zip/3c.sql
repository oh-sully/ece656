DELETE FROM Employee
WHERE empID IN (SELECT * 
			   FROM (SELECT E.empID 
					FROM Employee AS E NATURAL JOIN Department AS D 
					WHERE D.location = 'Kitchener') AS X);

UPDATE Department AS D
SET D.location = 'Waterloo'
WHERE D.location = 'Kitchener';