SELECT empID, num_proj
FROM (SELECT empID, COUNT(E.empID) as num_proj
	  FROM Employee as E NATURAL JOIN Assigned as A
	  GROUP BY E.empID
	  ) AS num_proj_T
WHERE num_proj > 1;