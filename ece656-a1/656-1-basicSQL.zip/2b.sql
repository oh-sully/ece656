SELECT empName, job, role
FROM Employee as E NATURAL JOIN Assigned as A
WHERE E.job <> A.role;