SELECT deptID, (num_eng_by_dept.num_eng / num_emp_by_dept.num_emp) AS percentage
FROM
	(
	SELECT deptID, COUNT(*) as num_emp 
	FROM Employee
	GROUP BY deptID
	) as num_emp_by_dept
	NATURAL JOIN
	(
	SELECT deptID, COUNT(*) as num_eng
	FROM Employee
	WHERE job = 'engineer'
	GROUP BY deptID
	) as num_eng_by_dept
ORDER BY num_eng_by_dept.num_eng/num_emp_by_dept.num_emp desc
LIMIT 1;