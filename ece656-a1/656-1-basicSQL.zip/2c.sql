SELECT job, COUNT(*) AS employeeNum
FROM Employee AS E NATURAL JOIN Assigned AS A
WHERE E.job = A.role
GROUP BY job;