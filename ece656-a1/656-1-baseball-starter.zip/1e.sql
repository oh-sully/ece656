SELECT 
	(SELECT SUM(HR) FROM Batting) 
	/ 
	(SELECT COUNT(Distinct playerID) FROM Batting as B WHERE B.HR > 0) AS averageHR;