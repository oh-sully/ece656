SELECT ((SELECT COUNT(Distinct HF.playerID) 
		FROM Master AS M NATURAL JOIN HallOfFame AS HF
		WHERE M.deathYear IS NULL
		AND HF.inducted = 'Y')
		- 
		(SELECT COUNT(Distinct HF.playerID)
		FROM Master AS M NATURAL JOIN HallOfFame AS HF
		WHERE M.deathYear IS NOT NULL
		AND HF.inducted = 'Y'))
		AS alive_dead;