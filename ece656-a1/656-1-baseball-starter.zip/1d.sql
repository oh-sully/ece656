SELECT 
	((SELECT SUM(HR) FROM Batting) 
	/ 
	(SELECT COUNT(Distinct playerID) FROM Batting as B WHERE B.HR IS NOT NULL)) as averageHR;