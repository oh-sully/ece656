SELECT nameFirst, nameLast, totalPay
FROM (SELECT M.playerID, nameFirst, nameLast, SUM(salary) as totalPay
	  FROM Master as M NATURAL JOIN Salaries as S
	  GROUP BY M.playerID
	  ORDER BY totalPay desc) as ptotsal
LIMIT 1;