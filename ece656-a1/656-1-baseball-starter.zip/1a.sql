SELECT COUNT(*) as playerCount
FROM Master
WHERE birthDay IS NULL;