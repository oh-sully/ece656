CREATE VIEW avghr AS
SELECT 
	(SELECT SUM(HR) FROM Batting) 
	/ 
	(SELECT COUNT(Distinct playerID) FROM Batting as B WHERE B.HR IS NOT NULL) AS averageHR;

CREATE VIEW avgsho AS
SELECT 
	(SELECT SUM(sho) FROM Pitching)
	/
	(SELECT COUNT(Distinct playerID) FROM Pitching AS P) AS averagesho;

SELECT COUNT(Distinct B.playerID) as playerCount
FROM (SELECT playerID, SUM(HR) as totHR FROM Batting GROUP BY playerID) AS B 
	INNER JOIN 
	(SELECT playerID, SUM(sho) as totsho FROM Pitching GROUP BY playerID) AS P 
	ON B.playerID=P.playerID
WHERE (B.totHR > (SELECT * FROM avghr)) AND (P.totsho > (SELECT * FROM avgsho));